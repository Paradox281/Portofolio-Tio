"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react"

const projects = [
  {
    title: "Portfolio Website",
    description: "Website pribadi modern menggunakan Next.js + TailwindCSS dengan tema gelap.",
    tags: ["Next.js", "React", "TailwindCSS"],
    image: "/modern-portfolio-website.png",
    link: "#",
  },
  {
    title: "Dashboard Admin",
    description: "Dashboard untuk manajemen data berbasis React dengan integrasi API real-time.",
    tags: ["React", "TypeScript", "API"],
    image: "/admin-dashboard-interface.png",
    link: "#",
  },
  {
    title: "E-Commerce Platform",
    description: "Platform e-commerce lengkap dengan sistem pembayaran dan manajemen inventory.",
    tags: ["Next.js", "Stripe", "MySQL"],
    image: "/ecommerce-website-design.png",
    link: "#",
  },
  {
    title: "CMS Application",
    description: "Aplikasi Content Management System dengan fitur authoring dan publishing.",
    tags: ["React", "Node.js", "PostgreSQL"],
    image: "/cms-interface.png",
    link: "#",
  },
  {
    title: "Mobile App Landing",
    description: "Landing page responsive untuk aplikasi mobile dengan analytics terintegrasi.",
    tags: ["Next.js", "TailwindCSS", "Analytics"],
    image: "/mobile-app-landing-page.jpg",
    link: "#",
  },
  {
    title: "SaaS Dashboard",
    description: "Dashboard SaaS dengan multiple user roles dan permission management.",
    tags: ["Next.js", "Auth0", "Database"],
    image: "/saas-dashboard-template.jpg",
    link: "#",
  },
]

export default function ProjectsSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? projects.length - 1 : prev - 1))
  }

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === projects.length - 1 ? 0 : prev + 1))
  }

  const visibleProjects = [
    projects[currentIndex],
    projects[(currentIndex + 1) % projects.length],
    projects[(currentIndex + 2) % projects.length],
  ]

  return (
    <div className="space-y-8">
      <div className="grid lg:grid-cols-3 gap-6">
        {visibleProjects.map((project, idx) => (
          <div
            key={`${project.title}-${idx}`}
            className="group bg-background border border-border rounded-lg overflow-hidden hover:border-accent/50 transition duration-300"
          >
            <div className="relative h-48 overflow-hidden bg-card">
              <img
                src={project.image || "/placeholder.svg"}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition" />
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-xl font-bold text-pretty">{project.title}</h3>
                <ExternalLink
                  size={18}
                  className="opacity-0 group-hover:opacity-100 transition text-accent flex-shrink-0"
                />
              </div>
              <p className="text-foreground/60 text-sm">{project.description}</p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-accent/10 text-accent text-xs rounded-full">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation */}
      <div className="flex justify-center items-center gap-4">
        <button
          onClick={handlePrev}
          className="p-2 bg-accent/10 hover:bg-accent/20 text-accent rounded-full transition"
        >
          <ChevronLeft size={24} />
        </button>

        <div className="flex gap-2">
          {projects.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2 rounded-full transition ${idx === currentIndex ? "w-8 bg-accent" : "w-2 bg-border"}`}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          className="p-2 bg-accent/10 hover:bg-accent/20 text-accent rounded-full transition"
        >
          <ChevronRight size={24} />
        </button>
      </div>
    </div>
  )
}
